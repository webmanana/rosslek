import { Foundation } from './foundation.core';

import { AccordionMenu } from '../../foundation.accordionMenu';
Foundation.plugin(AccordionMenu, 'AccordionMenu');

export { Foundation, AccordionMenu };
