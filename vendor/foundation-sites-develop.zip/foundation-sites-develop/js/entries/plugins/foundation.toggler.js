import { Foundation } from './foundation.core';

import { Toggler } from '../../foundation.toggler';
Foundation.plugin(Toggler, 'Toggler');

export { Foundation, Toggler };
