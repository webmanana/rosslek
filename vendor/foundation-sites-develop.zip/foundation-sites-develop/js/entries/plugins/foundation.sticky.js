import { Foundation } from './foundation.core';

import { Sticky } from '../../foundation.sticky';
Foundation.plugin(Sticky, 'Sticky');

export { Foundation, Sticky };
