import { Foundation } from './foundation.core';

import { Dropdown } from '../../foundation.dropdown';
Foundation.plugin(Dropdown, 'Dropdown');

export { Foundation, Dropdown };
